# CUDA, OpenCV, TensorFlowのインストールおよびバージョン管理についてのメモ

現状、CUDAのインストール及び設定、cuDNN関連のライブラリ、
また、それを利用するような設定でのOpenCVとTensorFlowのインストールがうまく行っていない

これに関してインストールとバージョン管理の方法についてうまく行うまでのメモ

また、MySQLとPostgreSQLのローカルビルドについても検討する。
https://qiita.com/tomov3/items/cd2a3df22f025ff167cd
http://tomov3.hatenablog.com/entry/2016/08/01/175308
https://qiita.com/ekzemplaro/items/512a73578460576f3a5d
https://dev.mysql.com/downloads/connector/cpp/
https://qiita.com/houtarou/items/a44ce783d09201fc28f5
https://masayuki14.hatenablog.com/entry/2020/07/30/MySQL8.0%E3%81%AE%E3%83%87%E3%83%90%E3%83%83%E3%82%B0%E3%83%93%E3%83%AB%E3%83%89%E3%82%92%E3%82%8F%E3%82%8A%E3%81%A8%E8%A9%B3%E3%81%97%E3%81%8F%E6%9B%B8%E3%81%84%E3%81%A6%E3%81%BF%E3%82%8B
https://qiita.com/CyberMergina/items/f889519e6be19c46f5f4
https://qiita.com/yoheiW@github/items/bcbcd11e89bfc7d7f3ff
https://qiita.com/ponsuke0531/items/df51a784b5ff48c97ac7

## まずはCUDA
